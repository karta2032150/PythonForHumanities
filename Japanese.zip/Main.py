import tkinter as tk
import tkinter.font as tkFont
from tkinter import ttk
from tkinter import *
from PIL import ImageTk # pip install pillow
import random, datetime

voc = []

def readFile(file): # 把voc清空, 讀N?.txt進來放進voc
    voc.clear()
    fh = open(file + ".txt", "r", encoding = "utf-8")
    txt = fh.readlines()
    fh.close()
    for i in range(len(txt)):
        voc.append(txt[i].strip().split("\t"))
    random.shuffle(voc)

def writeFile(file): # 把voc用成字串放回N?.txt
    voc2 = []
    fh = open(file + ".txt", "w", encoding = "utf-8")

    for i in range(len(voc)):
        voc2.append("\t".join(voc[i]))

    fh.write("\n".join(voc2))
    fh.close()

rank = []

def readRankFile(diff): # 讀取rank.txt的內容 放到全域list rank
    rank.clear()
    fh = open("Rank" + diff + ".txt", "r", encoding = "utf-8")
    txt = fh.readlines()
    fh.close()
    for i in range(len(txt)):
        rank.append(txt[i].strip().split("\t")) 

def writeRankFile(score): # 按下存檔後, 把這次的紀錄存進rank.txt裡
    rank2 = []
    fh = open("Rank" + difficult + ".txt", "w", encoding = "utf-8")
    
    now = datetime.datetime.now()
    nowTimestr = now.strftime('%Y-%m-%d %H:%M:%S')
    rank.append([score, nowTimestr])
    
    for i in range(len(rank)):
        rank2.append("\t".join(rank[i]))

    fh.write("\n".join(rank2))
    fh.close()


class Japanese(tk.Tk):
    
    def __init__(self, *args, **kwargs):
        
        tk.Tk.__init__(self, *args, **kwargs)
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand = True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}

        for F in (StartPage, PageOne, PageTwo, PageThree):
            frame = F(container, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")
            
        self.show_frame(StartPage)

    def show_frame(self, cont):
        frame = self.frames[cont]
        frame.tkraise()

        
class StartPage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)

        f1 = tkFont.Font(size = 80, family = "Berlin Sans FB Demi", weight="bold") #標題
        f2 = tkFont.Font(size = 40, family = "Berlin Sans FB Demi", weight="bold") #標題

        self.imageNtuLib = ImageTk.PhotoImage(file = "NTU_Library.jpg")
        self.lblNtuLibPto = tk.Label(self, image = self.imageNtuLib, bg = "lavender",
                                  height = 725, width = 1433)
        self.lblNtuLibPto.grid(row = 0, column = 0, columnspan = 3, sticky = tk.E)

        self.btnGame = tk.Button(self, text = "開始遊戲", fg = "black", bg = "gold",
                            command=lambda: controller.show_frame(PageOne), font = f2)
        self.btnGame.grid(row = 1, column = 0, sticky = tk.W)

        self.btnRank = tk.Button(self, text = "遊玩紀錄表", fg = "black", bg = "green2",
                            command=lambda: controller.show_frame(PageTwo), font = f2)
        self.btnRank.grid(row = 1, column = 1)

        self.btnFalse = tk.Button(self, text = "錯誤次數表", fg = "black", bg = "firebrick3",
                            command=lambda: controller.show_frame(PageThree), font = f2)
        self.btnFalse.grid(row = 1, column = 2, sticky = tk.E)


class PageOne(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        
        self.ansNum = 0
        self.trueCount, self.falseCount = 0, 0

        f1 = tkFont.Font(size = 80, family = "Berlin Sans FB Demi", weight="bold") #標題
        f2 = tkFont.Font(size = 30, family = "Helvetica") #按鈕
        f3 = tkFont.Font(size = 40, family = "Courier New")
        f4 = tkFont.Font(size = 60, family = "Fixdsys") #計時器
        f5 = tkFont.Font(size = 25, family = "Fixdsys")
        f6 = tkFont.Font(size = 15, family = "Fixdsys")


        self.option = [voc[0][-3].replace(",", "\n"), voc[1][-3].replace(",", "\n"),
                       voc[2][-3].replace(",", "\n"), voc[3][-3].replace(",", "\n")] # 存4個選項的字義
        self.ansStr = self.option[0].replace(",", "\n") # 第一個當答案
        random.shuffle(self.option) # 打亂 讓第一個不會一直是答案
        
        #self.東東們########################
        self.lblCDtimer = tk.Label(self, text = "60", bg = "plum1", height = 2, width = 4, font = f4)
        self.lblCDtimer.grid(row = 0, column = 5, rowspan = 2)
        self.remaining = 1

        self.btnCount = tk.Button(self, text = "開始計時", command = self.startCount,
                              height = 1, width = 10, font = f5, bg = "DarkOrchid2")
        self.btnCount.grid(row = 3, column = 5)

        self.btnSave = tk.Button(self, text = "存檔", command = self.save,
                              height = 1, width = 10, font = f5, bg = "magenta2")
        self.btnSave.grid(row = 4, column = 5)

        self.lblInstructions = tk.Label(self,
                            text = "開始前按下開始計時\n讀秒結束後按下存檔\n(就是個普通的碼表\n沒有其他功能的碼表)",
                            bg="deeppink2",fg="black",height = 4, width = 18, font = f6)
        self.lblInstructions.grid(row = 5, column = 5)
        
        
        self.lblMain = tk.Label(self, text = voc[0][0], bg = "medium blue",fg = "light cyan",
                                height = 1, width = 20, font = f1) # 製作標題
        self.lblMain.grid(row = 0, column = 0, columnspan = 5, sticky = tk.W)
        
        self.score = tk.Label(self, text = "O：0 X：0", bg = "gray55", height = 1, width = 30, font = f3) # 圈?叉?
        self.score.grid(row = 1, column = 0, columnspan = 5)

        self.imageNtu = ImageTk.PhotoImage(file = "NTUJP.png")
        self.lblNtuPto = tk.Label(self, image = self.imageNtu, bg = "black", height = 60, width = 220)
        self.lblNtuPto.grid(row = 9, column = 4, columnspan = 2, sticky = tk.E)

        self.btnBackMain = tk.Button(self, text="回主選單", font = f2,
                                     bg = "olive drab", command=lambda: controller.show_frame(StartPage))
        self.btnBackMain.grid(row = 8, column = 5, columnspan = 2)
        #self.Btn########################
        self.btn1 = tk.Button(self, text = self.option[0], command = self.clickBtn1,
                              height = 5, width = 20, font = f2, bg = "cyan")
        self.btn2 = tk.Button(self, text = self.option[1], command = self.clickBtn2,
                              height = 5, width = 20, font = f2, bg = "green2")
        self.btn3 = tk.Button(self, text = self.option[2], command = self.clickBtn3,
                              height = 5, width = 20, font = f2, bg = "orange red2")
        self.btn4 = tk.Button(self, text = self.option[3], command = self.clickBtn4,
                              height = 5, width = 20, font = f2, bg = "yellow")
        self.btn1.grid(row = 4, column = 1, rowspan = 2, sticky = tk.N)
        self.btn2.grid(row = 4, column = 3, rowspan = 2, sticky = tk.N)
        self.btn3.grid(row = 7, column = 1, rowspan = 2, sticky = tk.S)
        self.btn4.grid(row = 7, column = 3, rowspan = 2, sticky = tk.S)

    def afterClickBtn(self, textChosen):
        #按鈕按下去會做...
        if textChosen == self.ansStr:
            self.trueCount += 1
            voc[self.ansNum][-2] = str(int(voc[self.ansNum][-2]) + 1)
            self.score.configure(text = "O：%d X：%d"%(self.trueCount, self.falseCount))
            
            # 做四個隨機不等整數 為答案和其他選項的index
            self.ansNum, b, c, d = random.sample(range(len(voc) - 1), 4)

            self.option = [voc[self.ansNum][-3], voc[b][-3], voc[c][-3], voc[d][-3]] # 4個選項的字義
            random.shuffle(self.option) # 打亂選項 讓答案不會一直在第一個

            self.question = voc[self.ansNum][0] # 答案的日文
            self.ansStr = voc[self.ansNum][-3].replace(",", "\n") # 答案的字義

            self.btn1.configure(text = self.option[0].replace(",", "\n")) # 把4個字義丟入按鈕
            self.btn2.configure(text = self.option[1].replace(",", "\n"))
            self.btn3.configure(text = self.option[2].replace(",", "\n"))
            self.btn4.configure(text = self.option[3].replace(",", "\n"))
            self.lblMain.configure(text = self.question)
            
        else:
            self.falseCount += 1
            voc[self.ansNum][-1] = str(int(voc[self.ansNum][-1]) + 1)
            self.score.configure(text = "O：%d X：%d"%(self.trueCount, self.falseCount))

    def startCount(self):
        readFile(difficult)
        self.countdown(60)
        self.score.configure(text = "O：0 X：0")
        self.trueCount, self.falseCount = 0, 0
        
    def save(self):
        writeFile(difficult)
        writeRankFile(self.score.cget("text"))
        
    def clickBtn1(self):
        textChosen = self.btn1.cget("text")
        self.afterClickBtn(textChosen)
        
    def clickBtn2(self):
        textChosen = self.btn2.cget("text")
        self.afterClickBtn(textChosen)
        
    def clickBtn3(self):
        textChosen = self.btn3.cget("text")
        self.afterClickBtn(textChosen)
        
    def clickBtn4(self):
        textChosen = self.btn4.cget("text")
        self.afterClickBtn(textChosen)

    def countdown(self, remaining = None):
        if remaining is not None:
            self.remaining = remaining

        if self.remaining <= 0:
            self.lblCDtimer.configure(text="GG")
            
        else:
            self.lblCDtimer.configure(text="%d" % self.remaining)
            self.remaining = self.remaining - 1
            self.after(1000, self.countdown)


########################################################

class PageTwo(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        f = tkFont.Font(size = 25, family = "Fixdsys", weight="bold")
        f1 = tkFont.Font(size = 20, family = "Fixdsys")

        button1 = tk.Button(self, text="回\n主\n選\n單", height = 6, width = 3, font = f,
                    fg="blue", bg='yellow', command=lambda: controller.show_frame(StartPage))
        button1.grid(row = 0, column = 0)
        
        
        button2 = tk.Button(self, text="重\n新\n整\n理", height = 6, width = 3, font = f,
                    fg="azure", bg='Slate blue1', command = self.renewRankList)
        button2.grid(row = 1, column = 0)

        self.listboxRank = Listbox(self, width=73, height=20,
                                   fg="deeppink2", bg='SeaGreen1', font=f)
        self.scrollbar1 = Scrollbar(self, orient = "vertical")
        self.listboxRank.config(yscrollcommand = self.scrollbar1.set)
        self.scrollbar1.config(command = self.listboxRank.yview)
        self.listboxRank.grid(row = 0, column = 1, rowspan = 2, columnspan = 2, sticky = "NEWS")
        self.scrollbar1.grid(row = 0, column = 7, rowspan = 7, sticky = N+S)

        self.scrollbar2 = Scrollbar(self, orient = "horizontal")
        self.listboxRank.config(xscrollcommand = self.scrollbar2.set)
        self.scrollbar2.config(command = self.listboxRank.xview)
        self.scrollbar2.grid(row = 3, column = 1, columnspan = 7, sticky = W+E)

        for rankk in rank:
            self.listboxRank.insert(END, rankk)

    def renewRankList(self):###1231321321313#######
        readRankFile(difficult)
        self.listboxRank.delete(0,END)
        for rankk in rank:
            self.listboxRank.insert(END, rankk)


######################################################

class PageThree(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        f = tkFont.Font(size = 25, family = "Fixdsys", weight="bold")
        f1 = tkFont.Font(size = 20, family = "Fixdsys")

        button1 = tk.Button(self, text="回\n主\n選\n單", height = 6, width = 3, font = f,
                    fg="blue", bg='yellow', command=lambda: controller.show_frame(StartPage))
        button1.grid(row = 0, column = 0)
        
        
        button2 = tk.Button(self, text="重\n新\n整\n理", height = 6, width = 3, font = f,
                    fg="azure", bg='Slate blue1', command=self.renewVocList)
        button2.grid(row = 1, column = 0)

        self.listboxVocList = Listbox(self, width=73, height=20,
                                   fg="deeppink2", bg='SeaGreen1', font=f)
        self.scrollbar1 = Scrollbar(self, orient = "vertical")
        self.listboxVocList.config(yscrollcommand = self.scrollbar1.set)
        self.scrollbar1.config(command = self.listboxVocList.yview)
        self.listboxVocList.grid(row = 0, column = 1, rowspan = 2, columnspan = 2, sticky = "NEWS")
        self.scrollbar1.grid(row = 0, column = 7, rowspan = 7, sticky = N+S)

        self.scrollbar2 = Scrollbar(self, orient = "horizontal")
        self.listboxVocList.config(xscrollcommand = self.scrollbar2.set)
        self.scrollbar2.config(command = self.listboxVocList.xview)
        self.scrollbar2.grid(row = 3, column = 1, columnspan = 7, sticky = W+E)

        for vocc in sorted(voc, key = lambda k: int(k[-1]), reverse = True):
            self.listboxVocList.insert(END, list(vocc[-1]) + vocc[0:-2])

        
    def renewVocList(self):
        readFile(difficult)
        self.listboxVocList.delete(0,END)
        for vocc in sorted(voc, key = lambda k: int(k[-1]), reverse = True):
            self.listboxVocList.insert(END, list(vocc[-1]) + vocc[0:-2])


difficult = "N" + input("(1)N1 (2)N2 (3)N3 (4)N4 (5)N5 >>  ")
readFile(difficult)
readRankFile(difficult)

app = Japanese()
app.mainloop()
