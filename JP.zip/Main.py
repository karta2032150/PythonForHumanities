import tkinter as tk
import tkinter.font as tkFont
from tkinter import ttk
from tkinter import *
from PIL import ImageTk # pip install pillow
import random, datetime

vocs = []

def readFile(file): # 把vocs清空, 再讀N_.txt進來放進vocs
    vocs.clear()
    fh = open(file + ".txt", "r", encoding = "utf-8")
    txt = fh.readlines()
    fh.close()
    for i in range(len(txt)):
        vocs.append(txt[i].strip().split("\t"))

def writeFile(file): # 把vocs用成字串放回N_.txt
    voc2 = []
    fh = open(file + ".txt", "w", encoding = "utf-8")

    for i in range(len(vocs)):
        voc2.append("\t".join(vocs[i]))

    fh.write("\n".join(voc2))
    fh.close()

ranks = []

def readRankFile(diff): # 把ranks清空, 再讀.txt進來放進ranks
    ranks.clear()
    fh = open("Rank" + diff + ".txt", "r", encoding = "utf-8")
    txt = fh.readlines()
    fh.close()
    for i in range(len(txt)):
        ranks.append(txt[i].strip().split("\t")) 

def writeRankFile(score): # 把ranks存進rank.txt裡
    rank2 = []
    fh = open("Rank" + difficult + ".txt", "w", encoding = "utf-8")
    
    now = datetime.datetime.now()
    nowTimestr = now.strftime('%Y-%m-%d %H:%M:%S')
    ranks.append([score, nowTimestr])
    
    for i in range(len(ranks)):
        rank2.append("\t".join(ranks[i]))

    fh.write("\n".join(rank2))
    fh.close()


class Japanese(tk.Tk):
    
    def __init__(self, *args, **kwargs):
        
        tk.Tk.__init__(self, *args, **kwargs)
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand = True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}

        for F in (StartPage, PageOne, PageTwo, PageThree):
            frame = F(container, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")
            
        self.show_frame(StartPage)

    def show_frame(self, cont):
        frame = self.frames[cont]
        frame.tkraise()

        
class StartPage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent)

        f1 = tkFont.Font(size = 80, family = "Berlin Sans FB Demi", weight="bold") #標題
        f2 = tkFont.Font(size = 40, family = "Berlin Sans FB Demi", weight="bold") #標題

        self.imageNtuLib = ImageTk.PhotoImage(file = "NTU_Library.jpg")
        self.lblNtuLibPto = tk.Label(self, image = self.imageNtuLib, bg = "lavender",
                                  height = 725, width = 1433)
        self.lblNtuLibPto.grid(row = 0, column = 0, columnspan = 3, sticky = tk.E)

        self.btnGame = tk.Button(self, text = "開始遊戲", fg = "black", bg = "gold",
                            command=lambda: controller.show_frame(PageOne), font = f2)
        self.btnGame.grid(row = 1, column = 0, sticky = tk.W)

        self.btnRank = tk.Button(self, text = "遊玩紀錄表", fg = "black", bg = "green2",
                            command=lambda: controller.show_frame(PageTwo), font = f2)
        self.btnRank.grid(row = 1, column = 1)

        self.btnFalse = tk.Button(self, text = "錯誤次數表", fg = "black", bg = "firebrick3",
                            command=lambda: controller.show_frame(PageThree), font = f2)
        self.btnFalse.grid(row = 1, column = 2, sticky = tk.E)


class PageOne(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        
        self.trueCount, self.falseCount = 0, 0

        f1 = tkFont.Font(size = 80, family = "Berlin Sans FB Demi", weight="bold") #題目
        f2 = tkFont.Font(size = 25, family = "Comic Sans MS") #按鈕
        f3 = tkFont.Font(size = 40, family = "Courier New")
        f4 = tkFont.Font(size = 60, family = "Fixdsys") #計時器
        f5 = tkFont.Font(size = 30, family = "Fixdsys")
        f6 = tkFont.Font(size = 15, family = "Fixdsys")
        
        #設定畫面########################
        self.lblCDtimer = tk.Label(self, text = "60", bg = "red",fg = "seagreen1", height = 2, width = 4, font = f4)
        self.lblCDtimer.grid(row = 0, column = 5, rowspan = 2)

        self.btnCount = tk.Button(self, text = "開始計時", command = self.startCount,
                              height = 2, width = 9, font = f5, fg = "snow", bg = "purple4")
        self.btnCount.grid(row = 3, column = 5)
               
        self.lblMain = tk.Label(self, text = "", bg = "medium blue",fg = "light cyan",
                                height = 1, width = 20, font = f1) # 製作標題
        self.lblMain.grid(row = 0, column = 0, columnspan = 5, sticky = tk.W)
        
        self.score = tk.Label(self, text = "O：0 X：0", bg = "gray55", height = 1, width = 30, font = f3) # 圈?叉?
        self.score.grid(row = 1, column = 0, columnspan = 5, sticky = tk.S)

        self.imageNtu = ImageTk.PhotoImage(file = "NTUJP.png")
        self.lblNtuPto = tk.Label(self, image = self.imageNtu, bg = "black", height = 60, width = 220)
        self.lblNtuPto.grid(row = 8, column = 4, columnspan = 2, sticky = tk.E)

        self.btnBackMain = tk.Button(self, text="回主選單", font = f2,
                                     bg = "olive drab", command=lambda: controller.show_frame(StartPage))
        self.btnBackMain.grid(row = 7, column = 5, columnspan = 2)
        
        self.btn1 = tk.Button(self, text = "", command = self.clickBtn1,
                              height = 5, width = 20, font = f2, bg = "cyan")
        self.btn2 = tk.Button(self, text = "", command = self.clickBtn2,
                              height = 5, width = 20, font = f2, bg = "green2")
        self.btn3 = tk.Button(self, text = "", command = self.clickBtn3,
                              height = 5, width = 20, font = f2, bg = "gold")
        self.btn4 = tk.Button(self, text = "", command = self.clickBtn4,
                              height = 5, width = 20, font = f2, bg = "dark orange")
        self.btn1.grid(row = 4, column = 1, rowspan = 2, sticky = tk.N)
        self.btn2.grid(row = 4, column = 3, rowspan = 2, sticky = tk.N)
        self.btn3.grid(row = 7, column = 1, rowspan = 2, sticky = tk.S)
        self.btn4.grid(row = 7, column = 3, rowspan = 2, sticky = tk.S)

        
    def clickBtn1(self):
        textChosen = self.btn1.cget("text")
        self.afterClickBtn(textChosen)
        
    def clickBtn2(self):
        textChosen = self.btn2.cget("text")
        self.afterClickBtn(textChosen)
        
    def clickBtn3(self):
        textChosen = self.btn3.cget("text")
        self.afterClickBtn(textChosen)
        
    def clickBtn4(self):
        textChosen = self.btn4.cget("text")
        self.afterClickBtn(textChosen)


    def setNewQuestion(self):
        self.ansNum, b, c, d = random.sample(range(len(vocs) - 1), 4)
        # 用四個隨機整數 為答案和其他選項的index

        self.option = [vocs[self.ansNum][-3].replace(",", "\n"), # 4個選項的字義
                        vocs[b][-3].replace(",", "\n"),
                        vocs[c][-3].replace(",", "\n"),
                        vocs[d][-3].replace(",", "\n")
                        ]
        random.shuffle(self.option) # 打亂選項 讓答案不會一直在第一個按鈕

        self.question = vocs[self.ansNum][0] # 答案的日文 (題目)
        self.ansStr = vocs[self.ansNum][-3].replace(",", "\n") # 答案的字義

        self.btn1.configure(text = self.option[0]) # 把4個字義丟入按鈕
        self.btn2.configure(text = self.option[1])
        self.btn3.configure(text = self.option[2])
        self.btn4.configure(text = self.option[3])
        self.lblMain.configure(text = self.question)

    def afterClickBtn(self, textChosen):
        #按鈕按下去會做...
        if textChosen == self.ansStr: # 如果選對
            self.trueCount += 1
            vocs[self.ansNum][-2] = str(int(vocs[self.ansNum][-2]) + 1) # 單字表檔的O +1
            self.score.configure(text = "O：%d X：%d"%(self.trueCount, self.falseCount))
            self.setNewQuestion()
        else: # 如果選錯
            self.falseCount += 1
            vocs[self.ansNum][-1] = str(int(vocs[self.ansNum][-1]) + 1) # 單字表檔的X +1
            self.score.configure(text = "O：%d X：%d"%(self.trueCount, self.falseCount))

    def startCount(self): # 按下開始計時
        self.setNewQuestion()
        self.countdown(5) # 倒數 倒數完後會 self.save()
        self.score.configure(text = "O：0 X：0") # 歸零, 初始化
        self.trueCount, self.falseCount = 0, 0 # 歸零, 初始化

        self.btn1.configure(text = self.option[0].replace(",", "\n")) # 把4個字義丟入按鈕
        self.btn2.configure(text = self.option[1].replace(",", "\n"))
        self.btn3.configure(text = self.option[2].replace(",", "\n"))
        self.btn4.configure(text = self.option[3].replace(",", "\n"))
        self.lblMain.configure(text = self.question)
        
    def TimeToZero(self): # 倒數結束後
        writeFile(difficult) # 存檔
        writeRankFile(self.score.cget("text"))

        self.btn1.configure(text = "") # 把4個按鈕清空
        self.btn2.configure(text = "")
        self.btn3.configure(text = "")
        self.btn4.configure(text = "")
        self.lblMain.configure(text = "")


    def countdown(self, remaining = None): # 倒數計時器
        if remaining is not None:
            self.remaining = remaining

        if self.remaining <= 0:
            self.lblCDtimer.configure(text="GG")
            self.TimeToZero() # 倒數結束完執行 self.TimeToZero()
            
        else:
            self.lblCDtimer.configure(text="%d" % self.remaining)
            self.remaining = self.remaining - 1
            self.after(1000, self.countdown)


########################################################

class PageTwo(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        f = tkFont.Font(size = 25, family = "Fixdsys", weight="bold")
        f1 = tkFont.Font(size = 20, family = "Fixdsys")

        button1 = tk.Button(self, text="回\n主\n選\n單", height = 6, width = 3, font = f,
                    fg="blue", bg='yellow', command=lambda: controller.show_frame(StartPage))
        button1.grid(row = 0, column = 0)
        
        
        button2 = tk.Button(self, text="重\n新\n整\n理", height = 6, width = 3, font = f,
                    fg="azure", bg='Slate blue1', command = self.renewRankList)
        button2.grid(row = 1, column = 0)

        self.listboxRank = Listbox(self, width=73, height=20,
                                   fg="deeppink2", bg='SeaGreen1', font=f)
        self.scrollbar1 = Scrollbar(self, orient = "vertical")
        self.listboxRank.config(yscrollcommand = self.scrollbar1.set)
        self.scrollbar1.config(command = self.listboxRank.yview)
        self.listboxRank.grid(row = 0, column = 1, rowspan = 2, columnspan = 2, sticky = "NEWS")
        self.scrollbar1.grid(row = 0, column = 7, rowspan = 7, sticky = N+S)

        self.scrollbar2 = Scrollbar(self, orient = "horizontal")
        self.listboxRank.config(xscrollcommand = self.scrollbar2.set)
        self.scrollbar2.config(command = self.listboxRank.xview)
        self.scrollbar2.grid(row = 3, column = 1, columnspan = 7, sticky = W+E)

        for rank in ranks:
            self.listboxRank.insert(END, rank)

    def renewRankList(self): # 重新整理遊玩紀錄表
        self.listboxRank.delete(0,END)
        for rank in ranks:
            self.listboxRank.insert(END, rank)


######################################################

class PageThree(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        f = tkFont.Font(size = 25, family = "Fixdsys", weight="bold")
        f1 = tkFont.Font(size = 20, family = "Fixdsys")

        button1 = tk.Button(self, text="回\n主\n選\n單", height = 6, width = 3, font = f,
                    fg="blue", bg='yellow', command=lambda: controller.show_frame(StartPage))
        button1.grid(row = 0, column = 0)
        
        button2 = tk.Button(self, text="重\n新\n整\n理", height = 6, width = 3, font = f,
                    fg="azure", bg='Slate blue1', command=self.renewVocList)
        button2.grid(row = 1, column = 0)

        self.listboxVocList = Listbox(self, width=73, height=20,
                                   fg="deeppink2", bg='SeaGreen1', font=f)
        self.scrollbar1 = Scrollbar(self, orient = "vertical")
        self.listboxVocList.config(yscrollcommand = self.scrollbar1.set)
        self.scrollbar1.config(command = self.listboxVocList.yview)
        self.listboxVocList.grid(row = 0, column = 1, rowspan = 2, columnspan = 2, sticky = "NEWS")
        self.scrollbar1.grid(row = 0, column = 7, rowspan = 7, sticky = N+S)

        self.scrollbar2 = Scrollbar(self, orient = "horizontal")
        self.listboxVocList.config(xscrollcommand = self.scrollbar2.set)
        self.scrollbar2.config(command = self.listboxVocList.xview)
        self.scrollbar2.grid(row = 3, column = 1, columnspan = 7, sticky = W+E)

        for voc in sorted(vocs, key = lambda k: int(k[-1]), reverse = True):
            self.listboxVocList.insert(END, list(voc[-1]) + voc[0:-2])

        
    def renewVocList(self):
        self.listboxVocList.delete(0,END)
        for voc in sorted(vocs, key = lambda k: int(k[-1]), reverse = True):
            self.listboxVocList.insert(END, list(voc[-1]) + voc[0:-2])

def main():
    readFile(difficult)
    readRankFile(difficult)
    
difficult = "N" + input("(1)N1 (2)N2 (3)N3 (4)N4 (5)N5 >>  ")
main()

app = Japanese()
app.mainloop()
